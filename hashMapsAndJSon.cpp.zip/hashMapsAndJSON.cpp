//hashMapsAndJSON
//AJones10-1-25

#include <iostream>
#include <unordered_map>
#include "json.hpp"

using namespace std;

int main() {


    //todo JSON Map
    // Create a JSON object / name
    nlohmann::json studentlist = {
        //     key       value    pair
        {"Jack",123},
        {"sam", 456},
        {"dan",789}
    };

    cout << "Student id of sam is: " << studentlist["sam"] << endl;






    //todo UnorderedMap
    unordered_map<string, int> StudentGrades;
    StudentGrades["Jack"] = 12;
    StudentGrades["sam"] = 45;
    StudentGrades["dan"] = 78;

    cout << "Jack's grade is: " << StudentGrades["Jack"] << endl;



    //cycling through a map using a for loop
    // using the adress of pair - pointer
        for (auto &pair : StudentGrades) {
            cout << pair.first << " " << pair.second << endl;
        }


    //todo ordered map
map<string, int> myOrderedTestScores;
    myOrderedTestScores["Jack"] = 99;
    myOrderedTestScores["sam"] = 87;
    myOrderedTestScores["dan"] = 62;

    for (auto &pair : myOrderedTestScores) {
        cout << pair.first << " " << pair.second << endl;
    }


    return 0;
}


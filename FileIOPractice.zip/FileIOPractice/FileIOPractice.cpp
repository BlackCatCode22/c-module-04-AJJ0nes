//FileIOPractice
//AJones 9-29-25

//Include Library
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

//todo innate program
int main() {


//todo - Read a file
    fstream file;// File placeholder fro oping multiple files
    fstream file2;// File placeholder fro oping multiple files
    file.open("arrivingAnimals.txt", ios::in);//todo opens the file from the pathway/root

    if (file.is_open()) {//todo if file is open
        string line;//creates a temp variable to use
        //while getting line asign it to temp variable until no lines are left
        while (getline(file, line)) {//todo while there is lines to read - iterate
            cout << line << endl;//todo print each line in the loop
        }
    file.close();//todo close the file after were done
    }else{//debug message for if file.open error
        cout << "Error!" << endl;//print error message
    }//end block


//todo - write a file
    //  creates a new txt file name is given/ ios:out creates a file
    file2.open("Temp.txt", ios::out);//todo Open the file
    if (file2.is_open()) {//todo If file is open
        file2 << "line1" << endl;
        file2 << "line2" << endl;
        file2 << "line3" << endl;
        file2.close();//to do CloseFile
    }else {//debug message for writing a file
        cout << "Error creating file" << endl;//print error message
    }//end block


//todo - read the newly created file
    file2.open("temp.txt", ios::in);//todo opens the file created eariler
    if (file2.is_open()) {//todo if file is open
        string line2;//creates temp variable to use
        cout << endl;//buffer space between output blocks
        while (getline(file2, line2)) {//todo while there is lines to read - iterate
            cout << line2 << endl;//print each line in loop
        }
        file2.close();//todo close the file
    }else {//debug message for reading new file
        cout << "Error reading the creating file" << endl;//output error message
    }//end block

    return 0;//returns 0 for int(Main)
}//todo end of program